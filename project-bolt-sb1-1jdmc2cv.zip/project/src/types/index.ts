export interface StudentData {
  studentName: string;
  branch: string;
  score: number;
  answers: { [key: string]: string };
}

export interface QuestionStats {
  questionNumber: string;
  answers: {
    [key: string]: {
      count: number;
      percentage: number;
    };
  };
  totalResponses: number;
}