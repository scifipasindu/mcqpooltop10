import React, { useState } from 'react';
import { FileUploader } from './components/FileUploader';
import { TopRankers } from './components/TopRankers';
import { BranchAnalytics } from './components/BranchAnalytics';
import { QuestionAnalytics } from './components/QuestionAnalytics';
import { parseExcelData } from './utils/excelParser';
import type { StudentData } from './types';

function App() {
  const [studentData, setStudentData] = useState<StudentData[]>([]);
  const [currentDataset, setCurrentDataset] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'overview' | 'branches' | 'questions'>('overview');

  const handleDataLoad = (rawData: any[], filename: string) => {
    try {
      const parsedData = parseExcelData(rawData);
      
      if (parsedData.length === 0) {
        alert('No valid student data found in the file. Please check the file format and try again.');
        return;
      }
      
      setStudentData(parsedData);
      
      // Clean up filename for display
      const cleanFilename = filename
        .replace(/\.(xlsx|xls)$/i, '')
        .replace(/[_-]/g, ' ')
        .trim();
      setCurrentDataset(cleanFilename);
      
      console.log(`Successfully loaded ${parsedData.length} student records from ${filename}`);
    } catch (error) {
      console.error('Error parsing data:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred while parsing data';
      alert(`Failed to load data: ${errorMessage}`);
      setStudentData([]);
      setCurrentDataset('');
    }
  };

  const tabs = [
    { id: 'overview', label: 'Performance Overview', icon: '📊' },
    { id: 'branches', label: 'Branch Analytics', icon: '🏢' },
    { id: 'questions', label: 'Question Analysis', icon: '❓' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden dashboard-container">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-indigo-600/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-gradient-to-tr from-purple-400/20 to-pink-600/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-cyan-400/10 to-blue-600/10 rounded-full blur-2xl animate-pulse"></div>
      </div>

      {/* Professional Header */}
      <div className="relative bg-white/90 backdrop-blur-xl shadow-2xl border-b border-gray-200/50 animate-slide-up dashboard-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-3 sm:space-x-4 group">
              <img 
                src="https://sakya.edu.lk/assets/images/logo/logo.png" 
                alt="Sakya Academy Logo" 
                className="h-12 sm:h-14 lg:h-16 w-auto flex-shrink-0 transition-transform duration-300 group-hover:scale-110 drop-shadow-lg"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iOCIgZmlsbD0iIzMzNzNkYyIvPgo8dGV4dCB4PSIyMCIgeT0iMjYiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5TPC90ZXh0Pgo8L3N2Zz4K';
                }}
              />
              <div className="text-center sm:text-left">
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold gradient-text mb-1 tracking-tight">
                  MCQ Analytics Platform
                </h1>
                <p className="text-sm sm:text-base lg:text-lg text-gray-600 font-medium opacity-90">
                  Enterprise-grade analytics for educational assessment
                </p>
              </div>
            </div>
            
            {/* Enhanced status indicator */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-green-50 px-4 py-2 rounded-full border border-green-200">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-green-700">System Online</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      {studentData.length > 0 && (
        <div className="relative bg-white/80 backdrop-blur-xl border-b border-gray-200/50 shadow-lg">
          <div className="max-w-7xl mx-auto px-6">
            <nav className="flex space-x-8 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center space-x-2 px-6 py-4 border-b-2 font-medium text-sm transition-all duration-300 whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600 bg-blue-50/50'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <span className="text-lg">{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-6 py-8 z-10">
        {studentData.length === 0 ? (
          <div className="flex items-center justify-center min-h-[60vh] animate-bounce-in">
            <FileUploader onDataLoad={handleDataLoad} />
          </div>
        ) : (
          <div className="animate-slide-up">
            {activeTab === 'overview' && (
              <TopRankers 
                data={studentData} 
                currentDataset={currentDataset}
                onDataLoad={handleDataLoad}
              />
            )}
            {activeTab === 'branches' && (
              <BranchAnalytics 
                data={studentData}
              />
            )}
            {activeTab === 'questions' && (
              <QuestionAnalytics 
                data={studentData}
              />
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="relative bg-white/95 backdrop-blur-xl border-t border-gray-200/50 mt-16 shadow-xl">
        <div className="max-w-7xl mx-auto px-8 py-8">
          <div className="text-center space-y-3">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-1 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full"></div>
              <div className="w-4 h-1 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full"></div>
              <div className="w-8 h-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full"></div>
            </div>
            <p className="text-gray-700 font-medium text-base">
              © 2025 <a href="https://sakya.edu.lk" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors">Sakya Academy</a> Analytics Platform
            </p>
            <div>
              <p className="text-gray-600 text-sm">
                Developed by <a href="https://pasindulakshan.com/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 font-semibold transition-colors">Pasindu Lakshan Perera</a>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;