import type { StudentData } from '../types';

export function parseExcelData(rawData: any[]): StudentData[] {
  if (!rawData || rawData.length < 2) {
    throw new Error('Invalid data format. File must contain at least a header row and one data row.');
  }

  const headers = rawData[0] as string[];
  const rows = rawData.slice(1);

  // Validate headers exist
  if (!headers || headers.length === 0) {
    throw new Error('No headers found in the Excel file.');
  }

  // Find column indices with enhanced matching
  const studentNameIndex = headers.findIndex(h => {
    if (!h || typeof h !== 'string') return false;
    const headerLower = h.toLowerCase().trim();
    return headerLower === 'student name' || 
           headerLower === 'full name' || 
           headerLower === 'name' ||
           headerLower === 'student' ||
           headerLower === 'participant' ||
           headerLower.includes('student name') ||
           headerLower.includes('full name');
  });
  
  const branchIndex = headers.findIndex(h => {
    if (!h || typeof h !== 'string') return false;
    const headerLower = h.toLowerCase().trim();
    return headerLower === 'branch' || 
           headerLower === 'class' ||
           headerLower === 'grade' ||
           headerLower === 'section' ||
           headerLower.includes('branch') ||
           headerLower.includes('class');
  });
  
  const scoreIndex = headers.findIndex(h => {
    if (!h || typeof h !== 'string') return false;
    const headerLower = h.toLowerCase().trim();
    return headerLower === 'score' || 
           headerLower === 'total' ||
           headerLower === 'marks' ||
           headerLower === 'points' ||
           headerLower.includes('score') ||
           headerLower.includes('total');
  });

  // Enhanced error messages
  const missingColumns = [];
  if (studentNameIndex === -1) missingColumns.push('Student Name');
  if (branchIndex === -1) missingColumns.push('Branch/Class');
  if (scoreIndex === -1) missingColumns.push('Score/Total');

  if (missingColumns.length > 0) {
    throw new Error(`Required columns not found: ${missingColumns.join(', ')}. Available columns: ${headers.filter(h => h).join(', ')}`);
  }

  // Find question columns (Q1-Q50)
  const questionColumns: { [key: string]: number } = {};
  headers.forEach((header, index) => {
    if (header && typeof header !== 'undefined') {
      const headerStr = header.toString().trim();
      // Enhanced pattern matching for question columns
      const questionMatch = headerStr.match(/^(?:Q|Question\s*)?(\d{1,2})(?:\s|$)/i);
      if (questionMatch) {
        const questionNum = parseInt(questionMatch[1]);
        if (questionNum >= 1 && questionNum <= 50) {
          questionColumns[`Q${questionNum}`] = index;
        }
      } else if (/^\d{1,2}$/.test(headerStr)) {
        const questionNum = parseInt(headerStr);
        if (questionNum >= 1 && questionNum <= 50) {
          questionColumns[`Q${questionNum}`] = index;
        }
      }
    }
  });

  const parsedStudents = rows
    .filter(row => {
      // Enhanced filtering for better data quality
      return row && 
             row[studentNameIndex] && 
             row[branchIndex] && 
             row[scoreIndex] !== undefined && 
             row[scoreIndex] !== null &&
             row[scoreIndex] !== '' &&
             String(row[studentNameIndex]).trim().length > 0 &&
             String(row[branchIndex]).trim().length > 0;
    })
    .map(row => {
      // Initialize answers object for each student
      const answers: { [key: string]: string } = {};
      
      Object.entries(questionColumns).forEach(([questionKey, columnIndex]) => {
        const answer = row[columnIndex];
        // Precise answer validation and formatting
        if (answer === undefined || answer === null || answer === '') {
          answers[questionKey] = 'No Response';
        } else {
          const answerStr = String(answer).trim();
          // Strict validation for MCQ answers (A, B, C, D, E only)
          if (/^[A-E]$/i.test(answerStr)) {
            answers[questionKey] = answerStr.toUpperCase();
          } else {
            answers[questionKey] = 'No Response';
          }
        }
      });

      // Enhanced score parsing with better validation
      let score = 0;
      const scoreValue = row[scoreIndex];
      if (typeof scoreValue === 'number') {
        score = scoreValue;
      } else if (typeof scoreValue === 'string') {
        const parsedScore = parseFloat(scoreValue.replace(/[^\d.-]/g, ''));
        score = isNaN(parsedScore) ? 0 : parsedScore;
      }

      return {
        studentName: String(row[studentNameIndex] || '').trim().replace(/\s+/g, ' '),
        branch: String(row[branchIndex] || '').trim().replace(/\s+/g, ' '),
        score: Math.max(0, score), // Ensure non-negative scores
        answers
      };
    })
    .filter(student => {
      // Enhanced final validation for data accuracy
      return student.studentName.length > 0 && 
             student.branch.length > 0 &&
             !isNaN(student.score) &&
             student.score >= 0 &&
             student.studentName.length <= 100 &&
             student.branch.length <= 50 &&
             student.studentName !== 'undefined' &&
             student.branch !== 'undefined';
    });

  if (parsedStudents.length === 0) {
    throw new Error('No valid student data found. Please check that your Excel file contains proper student names, branches, and scores.');
  }

  return parsedStudents;
}