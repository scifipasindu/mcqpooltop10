import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Users, TrendingUp } from 'lucide-react';
import type { StudentData } from '../types';

interface BranchAnalyticsProps {
  data: StudentData[];
}

const COLORS = [
  '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef',
  '#ec4899', '#f43f5e', '#ef4444', '#f97316', '#f59e0b',
  '#eab308', '#84cc16', '#22c55e', '#10b981', '#14b8a6',
  '#06b6d4', '#0ea5e9', '#3b82f6'
];

export const BranchAnalytics: React.FC<BranchAnalyticsProps> = ({ data }) => {
  // Calculate branch distribution
  const branchStats = React.useMemo(() => {
    const branchCounts: { [key: string]: number } = {};
    
    data.forEach(student => {
      if (student.branch) {
        branchCounts[student.branch] = (branchCounts[student.branch] || 0) + 1;
      }
    });

    const total = Object.values(branchCounts).reduce((sum, count) => sum + count, 0);
    
    return Object.entries(branchCounts)
      .map(([branch, count]) => ({
        name: branch,
        value: count,
        percentage: ((count / total) * 100).toFixed(1)
      }))
      .sort((a, b) => b.value - a.value);
  }, [data]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-4 rounded-xl shadow-2xl border-2 border-blue-200">
          <p className="font-bold text-gray-800 mb-1">{data.name}</p>
          <p className="text-blue-600 font-semibold">{data.percentage}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="card-premium rounded-3xl shadow-xl border-2 border-gray-100 p-6 lg:p-8 animate-slide-up">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center space-x-3 mb-4">
          <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-3 shadow-xl animate-pulse-glow">
            <Users className="h-6 w-6 text-white" />
          </div>
          <h3 className="text-xl lg:text-2xl font-bold gradient-text">Branch Distribution</h3>
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl p-3 shadow-xl animate-pulse-glow" style={{ animationDelay: '0.5s' }}>
            <TrendingUp className="h-6 w-6 text-white" />
          </div>
        </div>
        <p className="text-gray-600 font-medium">Student distribution across branches</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pie Chart */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-200">
          <h4 className="text-lg font-bold text-gray-800 mb-4 text-center">Distribution Chart</h4>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={branchStats}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ percentage }) => `${percentage}%`}
                  labelLine={false}
                >
                  {branchStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Statistics List */}
        <div className="space-y-3">
          <h4 className="text-lg font-bold text-gray-800 mb-4 text-center">Branch Breakdown</h4>
          <div className="space-y-3 max-h-64 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
            {branchStats.map((branch, index) => (
              <div 
                key={branch.name}
                className="flex items-center justify-between p-4 bg-white rounded-xl shadow-md border border-gray-200 hover:shadow-lg transition-all duration-300 card-hover"
              >
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-4 h-4 rounded-full shadow-lg"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="font-semibold text-gray-800 text-sm">{branch.name}</span>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-gray-900">{branch.percentage}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};