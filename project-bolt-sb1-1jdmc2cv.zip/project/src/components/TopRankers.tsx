import React, { useState, useMemo } from 'react';
import { Trophy, Medal, Award, Filter, FileText, Crown, Star, BarChart3, Users, Target, TrendingUp } from 'lucide-react';
import type { StudentData } from '../types';

interface TopRankersProps {
  data: StudentData[];
  currentDataset: string;
  onDataLoad: (data: any[], filename: string) => void;
}

export const TopRankers: React.FC<TopRankersProps> = ({ data, currentDataset }) => {
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [showCount, setShowCount] = useState<number>(10);

  // Get unique branches
  const branches = useMemo(() => {
    const uniqueBranches = [...new Set(data.map(student => student.branch))].filter(Boolean);
    return uniqueBranches.sort();
  }, [data]);

  // Filter and rank students
  const rankedStudents = useMemo(() => {
    let filteredData = selectedBranch === 'all' 
      ? data 
      : data.filter(student => student.branch === selectedBranch);

    // Remove students with invalid scores and optimize filtering
    filteredData = filteredData.filter(student => 
      typeof student.score === 'number' && 
      !isNaN(student.score) && 
      student.score >= 0 &&
      student.studentName.trim().length > 0 &&
      student.branch.trim().length > 0
    );

    // Optimized sorting with better performance
    const sorted = [...filteredData].sort((a, b) => {
      // Primary sort by score (descending)
      if (b.score !== a.score) {
        return b.score - a.score;
      }
      // Secondary sort by name (ascending) for consistent ordering of ties - optimized
      return a.studentName.localeCompare(b.studentName, undefined, { numeric: true, sensitivity: 'base' });
    });

    // Optimized rank assignment with better tie handling
    const ranked = [];
    let currentRank = 1;
    
    for (let i = 0; i < sorted.length; i++) {
      const student = sorted[i];
      
      if (i > 0 && sorted[i - 1].score !== student.score) {
        currentRank = i + 1;
      }
      
      ranked.push({
        ...student,
        rank: currentRank
      });
    }

    return ranked;
  }, [data, selectedBranch]);

  // Performance optimization: Calculate statistics
  const statistics = useMemo(() => {
    const totalStudents = rankedStudents.length;
    const averageScore = totalStudents > 0 ? rankedStudents.reduce((sum, s) => sum + s.score, 0) / totalStudents : 0;
    const highestScore = totalStudents > 0 ? rankedStudents[0]?.score || 0 : 0;
    const lowestScore = totalStudents > 0 ? rankedStudents[totalStudents - 1]?.score || 0 : 0;
    return { totalStudents, averageScore, highestScore, lowestScore };
  }, [rankedStudents]);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-5 w-5 text-yellow-600" />;
      case 2:
        return <Medal className="h-5 w-5 text-gray-500" />;
      case 3:
        return <Award className="h-5 w-5 text-amber-600" />;
      default:
        return null;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 2:
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 3:
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getRankDisplay = (rank: number) => {
    const icon = getRankIcon(rank);
    const badgeColor = getRankBadgeColor(rank);
    
    return (
      <div className="flex flex-col items-center space-y-2">
        {icon && (
          <div className="flex items-center justify-center">
            {icon}
          </div>
        )}
        <div className={`px-3 py-1 text-sm font-bold rounded-full border ${badgeColor} min-w-[40px] text-center`}>
          #{rank}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Enhanced Header with Statistics */}
      <div className="card-premium rounded-3xl shadow-xl border-2 border-gray-100 p-6 lg:p-8 animate-slide-up">
        <div className="flex flex-col space-y-4 sm:space-y-6">
          {/* Title Section */}
          <div className="text-center">
            <div className="mb-6">
              <div className="relative inline-block mb-6">
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl blur-xl opacity-40 animate-pulse"></div>
                <div className="relative inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-xl shadow-xl animate-pulse-glow">
                  <Trophy className="h-6 w-6 text-white drop-shadow-lg" />
                </div>
              </div>
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold gradient-text mb-3 leading-tight tracking-tight">
                🏆 Top Rankers Leaderboard
              </h2>
              <p className="text-sm sm:text-base lg:text-lg text-gray-600 font-medium max-w-3xl mx-auto leading-relaxed opacity-90">
                Celebrating academic excellence and achievement
              </p>
            </div>
          </div>
          
          {/* Statistics Dashboard */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 border border-blue-200 text-center card-hover">
              <div className="text-2xl font-bold text-blue-800">{statistics.averageScore.toFixed(1)}</div>
              <div className="text-xs font-semibold text-blue-600 uppercase tracking-wide">Average Score</div>
            </div>
            <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-4 border border-yellow-200 text-center card-hover">
              <div className="text-2xl font-bold text-yellow-800">{statistics.highestScore}</div>
              <div className="text-xs font-semibold text-yellow-600 uppercase tracking-wide">Highest Score</div>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-xl p-4 border border-red-200 text-center card-hover">
              <div className="text-2xl font-bold text-purple-800">{statistics.lowestScore}</div>
              <div className="text-xs font-semibold text-red-600 uppercase tracking-wide">Lowest Score</div>
            </div>
          </div>
          
          {/* Enhanced Controls Section */}
          <div className="gradient-border">
            <div className="gradient-border-content p-6 lg:p-8">
              <div className="flex flex-col lg:flex-row items-center justify-center space-y-6 lg:space-y-0 lg:space-x-8">
                <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                      <Filter className="h-4 w-4 text-white" />
                    </div>
                    <label className="text-sm font-bold text-gray-800">Branch Filter:</label>
                  </div>
                  <select
                    value={selectedBranch}
                    onChange={(e) => setSelectedBranch(e.target.value)}
                    className="input-enhanced px-4 py-2 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 bg-white text-gray-900 font-semibold text-sm shadow-lg hover:shadow-xl transition-all duration-300 min-w-[160px]"
                  >
                    <option value="all">All Branches</option>
                    {branches.map(branch => (
                      <option key={branch} value={branch}>{branch}</option>
                    ))}
                  </select>
                </div>
            
                <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
                  <div className="flex items-center space-x-3">
                    <label className="text-sm font-bold text-gray-800">Show Top:</label>
                  </div>
                  <select
                    value={showCount}
                    onChange={(e) => setShowCount(Number(e.target.value))}
                    className="input-enhanced px-4 py-2 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 bg-white text-gray-900 font-semibold text-sm shadow-lg hover:shadow-xl transition-all duration-300 min-w-[120px]"
                  >
                    <option value={5}>Top 5</option>
                    <option value={10}>Top 10</option>
                    <option value={20}>Top 20</option>
                    <option value={50}>Top 50</option>
                    <option value={100}>Top 100</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Champions Podium */}
      {rankedStudents.length >= 3 && (
        <div className="professional-podium rounded-4xl shadow-5xl border-2 border-gray-200 p-8 lg:p-12 relative overflow-hidden animate-slide-up bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-indigo-400/20 rounded-full blur-3xl animate-float"></div>
            <div className="absolute top-0 right-0 w-28 h-28 bg-gradient-to-br from-purple-400/15 to-blue-400/15 rounded-full blur-2xl animate-float" style={{ animationDelay: '1s' }}></div>
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-40 h-40 bg-gradient-to-t from-indigo-400/15 to-blue-400/15 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
          </div>
        
          <div className="text-center mb-12 relative z-10">
            <div className="flex flex-col items-center justify-center space-y-6 mb-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl blur-xl opacity-40 animate-pulse"></div>
                <div className="relative bg-gradient-to-br from-blue-500 via-indigo-600 to-purple-600 rounded-2xl p-4 shadow-2xl animate-pulse-glow">
                  <Crown className="h-8 w-8 text-white drop-shadow-2xl" />
                </div>
              </div>
              <div>
                <h3 className="text-3xl lg:text-4xl font-bold gradient-text mb-3 tracking-tight">
                  🏆 Performance Leaders
                </h3>
                <p className="text-lg lg:text-xl text-gray-700 font-medium max-w-2xl mx-auto leading-relaxed">
                  Recognizing academic excellence and outstanding performance
                </p>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="flex items-center justify-center space-x-4 mb-6">
              <div className="w-16 h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent rounded-full"></div>
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
              <div className="w-16 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent rounded-full"></div>
            </div>
          </div>
        
          <div className="flex flex-col lg:flex-row justify-center items-end space-y-16 lg:space-y-0 lg:space-x-16 relative mx-auto max-w-7xl">
            {/* 2nd Place */}
            {rankedStudents[1] && (
              <div className="text-center transform hover:scale-105 transition-all duration-500 professional-card order-2 lg:order-1 animate-bounce-in group" style={{ animationDelay: '0.2s' }}>
                <div className="relative">
                  {/* Glowing effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-400 to-gray-500 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>
                  
                  <div className="relative bg-white rounded-3xl shadow-2xl border-2 border-slate-300 overflow-hidden p-8 mb-8 max-w-md backdrop-blur-sm group-hover:border-slate-400 transition-all duration-500">
                    <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-slate-400 via-gray-500 to-slate-400"></div>
                    
                    {/* Floating badge */}
                    <div className="absolute -top-6 -right-6 bg-gradient-to-br from-slate-500 to-gray-600 rounded-2xl w-16 h-16 flex items-center justify-center shadow-2xl border-3 border-white animate-float">
                      <span className="text-white font-bold text-xl">2</span>
                    </div>
                    
                    <div className="relative z-10 pt-2">
                      <div className="bg-gradient-to-br from-slate-100 via-slate-200 to-gray-300 rounded-3xl mx-auto mb-6 p-6 w-24 h-24 flex items-center justify-center shadow-2xl border-2 border-slate-300 group-hover:scale-110 transition-transform duration-500">
                        <Medal className="h-12 w-12 text-slate-700 drop-shadow-lg" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900 mb-4 truncate group-hover:text-slate-700 transition-colors duration-300">{rankedStudents[1].studentName}</h4>
                      <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-slate-100 to-gray-200 rounded-full border border-slate-300 shadow-md mb-6">
                        <p className="text-sm text-slate-700 font-bold">{rankedStudents[1].branch}</p>
                      </div>
                      <div className="bg-gradient-to-r from-slate-50 via-slate-100 to-gray-50 rounded-2xl border-2 border-slate-300 shadow-inner py-5 px-8 group-hover:shadow-xl transition-shadow duration-500">
                        <p className="text-3xl font-bold text-slate-800 mb-2">{rankedStudents[1].score}</p>
                        <p className="text-slate-600 font-bold uppercase tracking-wider text-base">Silver Medal</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Enhanced podium base */}
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-700 to-slate-500 rounded-t-3xl blur-sm opacity-40"></div>
                  <div className="relative bg-gradient-to-t from-slate-700 via-slate-600 to-slate-500 rounded-t-3xl h-36 w-48 flex flex-col items-center justify-center shadow-2xl border-2 border-slate-400 mx-auto group-hover:shadow-3xl transition-shadow duration-500">
                    <Medal className="h-8 w-8 text-white mb-3 drop-shadow-xl" />
                    <span className="text-white font-bold text-3xl drop-shadow-xl">2nd</span>
                    <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 text-sm text-slate-200 font-semibold opacity-90 tracking-wider">
                      SILVER
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 1st Place */}
            {rankedStudents[0] && (
              <div className="text-center transform hover:scale-105 transition-all duration-500 relative z-20 professional-card order-1 lg:order-2 animate-bounce-in group">
                <div className="relative">
                  {/* Enhanced glowing effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-4xl blur-2xl opacity-40 group-hover:opacity-60 transition-opacity duration-500 animate-pulse"></div>
                  
                  <div className="relative bg-white rounded-4xl shadow-5xl border-3 border-yellow-400 overflow-hidden p-10 mb-10 max-w-lg backdrop-blur-sm group-hover:border-yellow-500 transition-all duration-500">
                    <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-yellow-400 via-orange-400 to-yellow-400"></div>
                    
                    {/* Floating crown */}
                    <div className="absolute -top-8 -right-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl w-20 h-20 flex items-center justify-center shadow-2xl border-4 border-white animate-float">
                      <Crown className="h-10 w-10 text-white drop-shadow-2xl" />
                    </div>
                    
                    <div className="relative z-10 pt-6">
                      <div className="bg-gradient-to-br from-yellow-100 via-yellow-200 to-orange-200 rounded-4xl mx-auto mb-8 p-8 w-32 h-32 flex items-center justify-center shadow-2xl border-3 border-yellow-300 group-hover:scale-110 transition-transform duration-500 animate-float">
                        <Trophy className="h-16 w-16 text-yellow-700 drop-shadow-2xl" />
                      </div>
                      <h4 className="text-2xl font-bold text-gray-900 mb-6 truncate group-hover:text-yellow-800 transition-colors duration-300">{rankedStudents[0].studentName}</h4>
                      <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-yellow-100 to-orange-100 rounded-full border-2 border-yellow-300 shadow-lg mb-8">
                        <p className="text-lg text-yellow-800 font-bold">{rankedStudents[0].branch}</p>
                      </div>
                      <div className="bg-gradient-to-r from-yellow-50 via-yellow-100 to-orange-50 rounded-3xl border-3 border-yellow-300 shadow-inner py-8 px-10 group-hover:shadow-xl transition-shadow duration-500">
                        <p className="text-4xl font-bold text-yellow-800 mb-3">{rankedStudents[0].score}</p>
                        <p className="text-yellow-700 font-bold uppercase tracking-wider text-lg">Champion</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Enhanced podium base */}
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-yellow-800 to-yellow-600 rounded-t-4xl blur-sm opacity-50"></div>
                  <div className="relative bg-gradient-to-t from-yellow-800 via-yellow-700 to-yellow-500 rounded-t-4xl h-48 w-56 flex flex-col items-center justify-center shadow-3xl border-3 border-yellow-400 mx-auto group-hover:shadow-4xl transition-shadow duration-500">
                    <Crown className="h-10 w-10 text-white mb-4 drop-shadow-2xl" />
                    <span className="text-white font-bold text-4xl drop-shadow-2xl mb-2">1st</span>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-base text-yellow-200 font-bold opacity-90 tracking-wider">
                      CHAMPION
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3rd Place */}
            {rankedStudents[2] && (
              <div className="text-center transform hover:scale-105 transition-all duration-500 professional-card order-3 animate-bounce-in group" style={{ animationDelay: '0.4s' }}>
                <div className="relative">
                  {/* Glowing effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-400 to-orange-500 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>
                  
                  <div className="relative bg-white rounded-3xl shadow-2xl border-2 border-amber-300 overflow-hidden p-8 mb-8 max-w-md backdrop-blur-sm group-hover:border-amber-400 transition-all duration-500">
                    <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-400 via-orange-400 to-amber-400"></div>
                    
                    {/* Floating badge */}
                    <div className="absolute -top-6 -right-6 bg-gradient-to-br from-amber-400 to-orange-500 rounded-2xl w-16 h-16 flex items-center justify-center shadow-2xl border-3 border-white animate-float">
                      <span className="text-white font-bold text-xl">3</span>
                    </div>
                    
                    <div className="relative z-10 pt-2">
                      <div className="bg-gradient-to-br from-amber-100 via-amber-200 to-orange-200 rounded-3xl mx-auto mb-6 p-6 w-24 h-24 flex items-center justify-center shadow-2xl border-2 border-amber-300 group-hover:scale-110 transition-transform duration-500">
                        <Award className="h-12 w-12 text-amber-800 drop-shadow-lg" />
                      </div>
                      <h4 className="text-xl font-bold text-gray-900 mb-4 truncate group-hover:text-amber-800 transition-colors duration-300">{rankedStudents[2].studentName}</h4>
                      <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-amber-100 to-orange-100 rounded-full border border-amber-300 shadow-md mb-6">
                        <p className="text-sm text-amber-800 font-bold">{rankedStudents[2].branch}</p>
                      </div>
                      <div className="bg-gradient-to-r from-amber-50 via-amber-100 to-orange-50 rounded-2xl border-2 border-amber-300 shadow-inner py-5 px-8 group-hover:shadow-xl transition-shadow duration-500">
                        <p className="text-3xl font-bold text-amber-800 mb-2">{rankedStudents[2].score}</p>
                        <p className="text-amber-700 font-bold uppercase tracking-wider text-base">Bronze Medal</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Enhanced podium base */}
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-amber-800 to-amber-600 rounded-t-3xl blur-sm opacity-40"></div>
                  <div className="relative bg-gradient-to-t from-amber-800 via-amber-700 to-amber-600 rounded-t-3xl h-32 w-48 flex flex-col items-center justify-center shadow-2xl border-2 border-amber-400 mx-auto group-hover:shadow-3xl transition-shadow duration-500">
                    <Award className="h-8 w-8 text-white mb-3 drop-shadow-xl" />
                    <span className="text-white font-bold text-3xl drop-shadow-xl">3rd</span>
                    <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 text-sm text-amber-200 font-semibold opacity-90 tracking-wider">
                      BRONZE
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Enhanced Leaderboard Table */}
      <div className="professional-table-container rounded-3xl shadow-2xl border border-gray-200 overflow-hidden animate-slide-up">
        {/* Professional Header */}
        <div className="bg-gradient-to-r from-slate-800 via-gray-800 to-slate-900 px-6 lg:px-8 py-6 lg:py-8 border-b border-gray-700 relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-40 h-40 bg-white opacity-5 rounded-full -mr-20 -mt-20"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white opacity-5 rounded-full -ml-16 -mb-16"></div>
          <div className="flex flex-col lg:flex-row items-center justify-between space-y-4 lg:space-y-0 relative z-10">
            <div className="flex items-center space-x-4 lg:space-x-6">
              <img 
                src="https://sakya.edu.lk/assets/images/logo/logo.png" 
                alt="Sakya Academy Logo" 
                className="h-8 lg:h-10 w-auto filter brightness-0 invert drop-shadow-xl"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iOCIgZmlsbD0iIzMzNzNkYyIvPgo8dGV4dCB4PSIyMCIgeT0iMjYiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IndoaXRlIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5TPC90ZXh0Pgo8L3N2Zz4K';
                }}
              />
              <div>
                <h1 className="text-xl lg:text-2xl font-bold text-white drop-shadow-xl tracking-tight">Performance Leaderboard</h1>
                <p className="text-gray-300 text-sm lg:text-base font-medium mt-1">Comprehensive student ranking system</p>
              </div>
            </div>
            <div className="text-center lg:text-right text-white relative">
              <div className="glass-dark rounded-xl px-6 lg:px-8 py-3 lg:py-4 shadow-xl border border-white/20">
                <div className="flex items-center justify-center lg:justify-end mb-3">
                  <div className="p-2 bg-white/20 rounded-lg mr-3">
                    <Trophy className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
                  </div>
                  <p className="text-sm lg:text-base font-bold drop-shadow-lg">Top {showCount} Performers</p>
                </div>
                <p className="text-sm text-gray-300 font-medium mb-1">{new Date().toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</p>
                <p className="text-xs text-gray-400 font-medium">Generated at {new Date().toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true
                })}</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Dataset Information */}
        {currentDataset && (
          <div className="bg-gradient-to-r from-slate-50 via-gray-50 to-slate-50 border-b border-gray-200 px-6 lg:px-8 py-4 lg:py-5">
            <div className="flex items-center justify-center space-x-3 lg:space-x-4">
              <div className="bg-gradient-to-br from-slate-600 to-gray-700 rounded-lg p-2 shadow-lg">
                <FileText className="h-4 w-4 text-white" />
              </div>
              <div className="text-center">
                <p className="text-xs text-slate-600 font-bold uppercase tracking-wider mb-1">Active Dataset</p>
                <p className="text-base lg:text-lg text-slate-800 font-bold">{currentDataset}</p>
              </div>
              <div className="bg-gradient-to-br from-gray-600 to-slate-700 rounded-lg p-2 shadow-lg">
                <BarChart3 className="h-4 w-4 text-white" />
              </div>
            </div>
          </div>
        )}
        
        <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 p-2">
          <table className="w-full professional-table-enhanced">
            <thead className="bg-gradient-to-r from-slate-100 via-gray-100 to-slate-100 border-b-2 border-slate-300">
              <tr>
                <th className="px-4 lg:px-6 py-4 lg:py-5 text-center text-sm lg:text-base font-bold text-slate-800 uppercase tracking-wider w-24 lg:w-28">
                  <div className="flex items-center justify-center space-x-3">
                    <div className="p-2 bg-slate-200 rounded-lg">
                      <Trophy className="h-4 w-4 text-slate-700" />
                    </div>
                    <span>Rank</span>
                  </div>
                </th>
                <th className="px-4 lg:px-6 py-4 lg:py-5 text-left text-sm lg:text-base font-bold text-slate-800 uppercase tracking-wider">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-slate-200 rounded-lg">
                      <Users className="h-4 w-4 text-slate-700" />
                    </div>
                    <span>Student Name</span>
                  </div>
                </th>
                <th className="px-4 lg:px-6 py-4 lg:py-5 text-left text-sm lg:text-base font-bold text-slate-800 uppercase tracking-wider">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-slate-200 rounded-lg">
                      <Target className="h-4 w-4 text-slate-700" />
                    </div>
                    <span>Branch</span>
                  </div>
                </th>
                <th className="px-4 lg:px-6 py-4 lg:py-5 text-center text-sm lg:text-base font-bold text-slate-800 uppercase tracking-wider w-24 lg:w-28">
                  <div className="flex items-center justify-center space-x-3">
                    <div className="p-2 bg-slate-200 rounded-lg">
                      <TrendingUp className="h-4 w-4 text-slate-700" />
                    </div>
                    <span>Score</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y-2 divide-gray-200">
              {rankedStudents.slice(0, showCount).map((student, index) => (
                <tr 
                  key={`${student.studentName}-${index}`}
                  className={`transition-all duration-400 hover:shadow-xl professional-row ${
                    student.rank <= 3 ? 'bg-gradient-to-r from-slate-50 via-blue-50 to-indigo-50 border-l-4 border-blue-500 shadow-md' : 'hover:border-l-4 hover:border-slate-400'
                  }`}
                >
                  <td className="px-4 lg:px-6 py-4 lg:py-5 whitespace-nowrap">
                    <div className="flex flex-col items-center justify-center">
                      {getRankDisplay(student.rank)}
                    </div>
                  </td>
                  <td className="px-4 lg:px-6 py-4 lg:py-5">
                    <div className="flex items-center space-x-4">
                      <div className={`w-5 h-5 rounded-full shadow-lg ${student.rank <= 3 ? 'bg-gradient-to-br from-blue-500 to-indigo-600' : 'bg-gradient-to-br from-slate-400 to-gray-500'}`}></div>
                      <div className="text-base lg:text-lg font-bold text-gray-900 break-words leading-tight" title={student.studentName}>
                        {student.studentName}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 lg:px-6 py-4 lg:py-5">
                    <div className="inline-flex items-center px-4 py-2 rounded-xl bg-gradient-to-r from-slate-100 to-gray-200 border border-slate-300 shadow-md">
                      <div className="text-sm lg:text-base font-bold text-slate-800 break-words" title={student.branch}>
                        {student.branch}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 lg:px-6 py-4 lg:py-5 whitespace-nowrap text-center">
                    <div className={`inline-flex items-center justify-center px-4 py-3 rounded-xl font-bold text-lg lg:text-xl shadow-xl border-2 transform hover:scale-105 transition-all duration-300 ${
                      student.rank === 1 ? 'bg-gradient-to-r from-yellow-100 via-yellow-200 to-orange-100 text-yellow-800 border-yellow-400 animate-pulse-glow' :
                      student.rank === 2 ? 'bg-gradient-to-r from-slate-100 via-slate-200 to-gray-300 text-slate-800 border-slate-400' :
                      student.rank === 3 ? 'bg-gradient-to-r from-amber-100 via-amber-200 to-orange-100 text-amber-800 border-amber-400' :
                      'bg-gradient-to-r from-slate-50 via-gray-50 to-slate-50 text-slate-800 border-slate-300'
                    }`}>
                      {typeof student.score === 'number' ? student.score.toFixed(1) : '0.0'}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {rankedStudents.slice(0, showCount).length === 0 && (
          <div className="px-8 lg:px-12 py-12 lg:py-16 text-center">
            <div className="text-gray-400 mb-8">
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-gray-300 rounded-full blur-lg opacity-30"></div>
                <Trophy className="relative h-12 w-12 lg:h-16 lg:w-16 mx-auto" />
              </div>
            </div>
            <p className="text-lg text-gray-500 font-semibold mb-2">No students found for the selected criteria.</p>
            <p className="text-base text-gray-400">Try adjusting your filters or upload new data.</p>
          </div>
        )}
      </div>
    </div>
  );
};