import React, { useCallback } from 'react';
import { Upload, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';

interface FileUploaderProps {
  onDataLoad: (data: any[], filename: string) => void;
  currentDataset?: string;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onDataLoad, currentDataset }) => {
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      console.warn('No file selected');
      return;
    }

    // Validate file type
    const validTypes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.ms-excel', // .xls
      'application/octet-stream' // Sometimes Excel files are detected as this
    ];
    
    const fileExtension = file.name.toLowerCase().split('.').pop();
    if (!['xlsx', 'xls'].includes(fileExtension || '')) {
      alert('Please upload a valid Excel file (.xlsx or .xls)');
      event.target.value = ''; // Reset input
      return;
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('File size too large. Please upload a file smaller than 10MB.');
      event.target.value = ''; // Reset input
      return;
    }

    const reader = new FileReader();
    
    reader.onerror = () => {
      console.error('Error reading file');
      alert('Error reading the file. Please try again.');
      event.target.value = ''; // Reset input
    };
    
    reader.onload = (e) => {
      try {
        if (!e.target?.result) {
          throw new Error('Failed to read file content');
        }
        
        const workbook = XLSX.read(e.target?.result, { type: 'binary' });
        
        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          throw new Error('No worksheets found in the Excel file');
        }
        
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        
        if (!sheet) {
          throw new Error('Unable to read the worksheet');
        }
        
        const data = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        
        if (!data || data.length === 0) {
          throw new Error('No data found in the Excel file');
        }
        
        onDataLoad(data, file.name);
        event.target.value = ''; // Reset input for future uploads
      } catch (error) {
        console.error('Error parsing Excel file:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        alert(`Error reading Excel file: ${errorMessage}\n\nPlease ensure it's a valid Excel format with proper data.`);
        event.target.value = ''; // Reset input
      }
    };
    
    reader.readAsBinaryString(file);
  }, [onDataLoad]);

  return (
    <div className="card-premium rounded-5xl shadow-5xl p-10 lg:p-12 border-2 border-gray-100 max-w-2xl mx-auto animate-bounce-in">
      {/* Decorative header */}
      <div className="text-center mb-8">
        <div className="relative inline-block">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full blur-lg opacity-30 animate-pulse"></div>
          <div className="relative mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 mb-4 shadow-2xl animate-pulse-glow">
            <Upload className="h-8 w-8 text-white" />
          </div>
        </div>
        
        <h3 className="text-xl lg:text-2xl font-bold gradient-text mb-3 tracking-tight">Upload MCQ Data</h3>
        <p className="text-gray-600 text-sm font-medium mb-6 max-w-md mx-auto leading-relaxed">
          Transform your Excel data into beautiful analytics and insights
        </p>
      </div>
      
      {/* Enhanced notice section */}
      <div className="gradient-border mb-8">
        <div className="gradient-border-content">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-orange-500 rounded-lg flex items-center justify-center shadow-lg">
                <FileText className="h-4 w-4 text-white" />
              </div>
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-bold text-gray-800 mb-2">File Naming Convention</h4>
              <p className="text-gray-700 mb-3 leading-relaxed text-sm">
                For optimal results, please rename your Excel file using this format:
              </p>
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-4 border-l-4 border-indigo-500">
                <code className="text-indigo-700 font-mono text-xs lg:text-sm font-semibold">
                  "Year MCQ Pool _Subject Day XX (Responses).xlsx"
                </code>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Current dataset display */}
      {currentDataset && (
        <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 border-2 border-blue-200 rounded-2xl p-6 mb-8 animate-slide-up">
          <div className="flex items-center justify-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-xl">
              <FileText className="h-5 w-5 text-white" />
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-blue-600 uppercase tracking-wider mb-1">Current Dataset</p>
              <p className="text-sm font-bold text-blue-900">{currentDataset}</p>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced upload section */}
      <div className="text-center">
        <label className="relative cursor-pointer group inline-block">
          <input
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileUpload}
            className="hidden"
          />
          <div className="btn-primary text-white font-bold py-3 px-8 rounded-xl inline-flex items-center text-sm shadow-2xl group-hover:shadow-3xl transform group-hover:-translate-y-1 group-active:scale-95 transition-all duration-300">
            <div className="mr-3 p-2 bg-white/20 rounded-xl">
              <Upload className="h-4 w-4" />
            </div>
            <span className="text-sm">Choose Excel File</span>
            <div className="ml-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </div>
        </label>
        
        <div className="mt-6 flex items-center justify-center space-x-6 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Supports .xlsx files</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Supports .xls files</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span>Max 10MB</span>
          </div>
        </div>
        
        {/* Feature highlights */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-100 card-hover">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg mx-auto mb-3 flex items-center justify-center shadow-lg">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <h4 className="text-sm font-bold text-gray-800 mb-2">Smart Analytics</h4>
            <p className="text-sm text-gray-600">Automatic data processing and insights</p>
          </div>
          
          <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border border-purple-100 card-hover">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg mx-auto mb-3 flex items-center justify-center shadow-lg">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </div>
            <h4 className="text-sm font-bold text-gray-800 mb-2">Real-time Analysis</h4>
            <p className="text-sm text-gray-600">Instant data visualization</p>
          </div>
          
          <div className="text-center p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-100 card-hover">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg mx-auto mb-3 flex items-center justify-center shadow-lg">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h4 className="text-sm font-bold text-gray-800 mb-2">Lightning Fast</h4>
            <p className="text-sm text-gray-600">Instant processing and visualization</p>
          </div>
        </div>
      </div>
    </div>
  );
};