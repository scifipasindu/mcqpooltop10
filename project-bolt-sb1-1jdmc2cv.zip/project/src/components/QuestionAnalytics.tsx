import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Search, Filter, BarChart3, Target, TrendingUp, Award, Users, BookOpen } from 'lucide-react';
import type { StudentData } from '../types';

interface QuestionAnalyticsProps {
  data: StudentData[];
}

export const QuestionAnalytics: React.FC<QuestionAnalyticsProps> = ({ data }) => {
  const [selectedBranch, setSelectedBranch] = useState<string>('all');
  const [questionFilter, setQuestionFilter] = useState<string>('');
  const [analysisType, setAnalysisType] = useState<'difficulty' | 'performance' | 'distribution'>('difficulty');

  // Get unique branches
  const branches = useMemo(() => {
    const uniqueBranches = [...new Set(data.map(student => student.branch))].filter(Boolean);
    return uniqueBranches.sort();
  }, [data]);

  // Filter data by branch
  const filteredData = useMemo(() => {
    return selectedBranch === 'all' 
      ? data 
      : data.filter(student => student.branch === selectedBranch);
  }, [data, selectedBranch]);

  // Get all available questions
  const availableQuestions = useMemo(() => {
    const questions = new Set<string>();
    filteredData.forEach(student => {
      Object.keys(student.answers).forEach(q => questions.add(q));
    });
    return Array.from(questions)
      .filter(q => q.match(/^Q\d+$/))
      .sort((a, b) => {
        const numA = parseInt(a.replace('Q', ''));
        const numB = parseInt(b.replace('Q', ''));
        return numA - numB;
      });
  }, [filteredData]);

  // Filter questions based on search
  const filteredQuestions = useMemo(() => {
    if (!questionFilter.trim()) return availableQuestions;
    
    const filter = questionFilter.toLowerCase().trim();
    return availableQuestions.filter(q => {
      const questionNum = q.replace('Q', '');
      return questionNum.includes(filter) || q.toLowerCase().includes(filter);
    });
  }, [availableQuestions, questionFilter]);

  // Calculate comprehensive question statistics
  const questionStats = useMemo(() => {
    return filteredQuestions.map(questionKey => {
      const answers: { [key: string]: number } = {};
      let totalResponses = 0;
      let correctAnswers = 0;

      filteredData.forEach(student => {
        const answer = student.answers[questionKey];
        if (answer && answer !== 'No Response' && answer !== 'Invalid') {
          answers[answer] = (answers[answer] || 0) + 1;
          totalResponses++;
          // Assume 'A' is correct for difficulty calculation (can be customized)
          if (answer === 'A') correctAnswers++;
        }
      });

      const difficulty = totalResponses > 0 ? ((correctAnswers / totalResponses) * 100) : 0;
      const difficultyLevel = difficulty >= 80 ? 'Easy' : difficulty >= 50 ? 'Medium' : 'Hard';

      const chartData = Object.entries(answers)
        .map(([answer, count]) => ({
          answer: answer,
          count: count,
          percentage: totalResponses > 0 ? ((count / totalResponses) * 100) : 0
        }))
        .sort((a, b) => b.count - a.count);

      return {
        questionNumber: questionKey,
        chartData,
        totalResponses,
        difficulty: difficulty,
        difficultyLevel,
        mostCommonAnswer: chartData[0]?.answer || 'N/A',
        responseRate: filteredData.length > 0 ? ((totalResponses / filteredData.length) * 100) : 0
      };
    });
  }, [filteredData, filteredQuestions]);

  // Calculate overall analytics
  const overallStats = useMemo(() => {
    const totalQuestions = questionStats.length;
    const avgResponseRate = questionStats.reduce((sum, q) => sum + q.responseRate, 0) / totalQuestions || 0;
    const easyQuestions = questionStats.filter(q => q.difficultyLevel === 'Easy').length;
    const mediumQuestions = questionStats.filter(q => q.difficultyLevel === 'Medium').length;
    const hardQuestions = questionStats.filter(q => q.difficultyLevel === 'Hard').length;

    return {
      totalQuestions,
      avgResponseRate,
      easyQuestions,
      mediumQuestions,
      hardQuestions
    };
  }, [questionStats]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-4 rounded-xl shadow-2xl border-2 border-blue-200">
          <p className="font-bold text-gray-800 mb-1">Answer: {label}</p>
          <p className="text-blue-600 font-semibold">{data.count} students ({data.percentage.toFixed(1)}%)</p>
        </div>
      );
    }
    return null;
  };

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'Easy': return 'text-green-600 bg-green-50 border-green-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'Hard': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-8">
      {/* Professional Analytics Header */}
      <div className="card-premium rounded-3xl shadow-xl border-2 border-gray-100 p-8 animate-slide-up">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl p-4 shadow-xl animate-pulse-glow">
              <BarChart3 className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold gradient-text">Question Analytics Dashboard</h2>
            <div className="bg-gradient-to-br from-pink-500 to-red-600 rounded-xl p-4 shadow-xl animate-pulse-glow" style={{ animationDelay: '0.5s' }}>
              <Target className="h-8 w-8 text-white" />
            </div>
          </div>
          <p className="text-lg text-gray-600 font-medium max-w-3xl mx-auto">
            Comprehensive analysis of question performance, difficulty levels, and response patterns
          </p>
        </div>

        {/* Overall Statistics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-4 border border-purple-200 text-center card-hover">
            <div className="text-2xl font-bold text-purple-800">{overallStats.avgResponseRate.toFixed(1)}%</div>
            <div className="text-xs font-semibold text-purple-600 uppercase tracking-wide">Avg Response Rate</div>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 border border-green-200 text-center card-hover">
            <div className="text-2xl font-bold text-green-800">{overallStats.easyQuestions}</div>
            <div className="text-xs font-semibold text-green-600 uppercase tracking-wide">Easy Questions</div>
          </div>
          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-4 border border-yellow-200 text-center card-hover">
            <div className="text-2xl font-bold text-yellow-800">{overallStats.mediumQuestions}</div>
            <div className="text-xs font-semibold text-yellow-600 uppercase tracking-wide">Medium Questions</div>
          </div>
          <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-xl p-4 border border-red-200 text-center card-hover">
            <div className="text-2xl font-bold text-red-800">{overallStats.hardQuestions}</div>
            <div className="text-xs font-semibold text-red-600 uppercase tracking-wide">Hard Questions</div>
          </div>
        </div>

        {/* Enhanced Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Branch Filter */}
          <div className="space-y-3">
            <label className="flex items-center space-x-2 text-sm font-bold text-gray-800">
              <Filter className="h-4 w-4 text-blue-600" />
              <span>Filter by Branch</span>
            </label>
            <select
              value={selectedBranch}
              onChange={(e) => setSelectedBranch(e.target.value)}
              className="w-full input-enhanced px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 bg-white text-gray-900 font-semibold text-sm shadow-lg"
            >
              <option value="all">All Branches</option>
              {branches.map(branch => (
                <option key={branch} value={branch}>{branch}</option>
              ))}
            </select>
          </div>

          {/* Question Filter */}
          <div className="space-y-3">
            <label className="flex items-center space-x-2 text-sm font-bold text-gray-800">
              <Search className="h-4 w-4 text-purple-600" />
              <span>Search Questions</span>
            </label>
            <input
              type="text"
              placeholder="Enter question number..."
              value={questionFilter}
              onChange={(e) => setQuestionFilter(e.target.value)}
              className="w-full input-enhanced px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 bg-white text-gray-900 font-semibold text-sm shadow-lg"
            />
          </div>

          {/* Analysis Type */}
          <div className="space-y-3">
            <label className="flex items-center space-x-2 text-sm font-bold text-gray-800">
              <BarChart3 className="h-4 w-4 text-green-600" />
              <span>Analysis Type</span>
            </label>
            <select
              value={analysisType}
              onChange={(e) => setAnalysisType(e.target.value as any)}
              className="w-full input-enhanced px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-green-500/20 focus:border-green-500 bg-white text-gray-900 font-semibold text-sm shadow-lg"
            >
              <option value="difficulty">Difficulty Analysis</option>
              <option value="performance">Performance Analysis</option>
              <option value="distribution">Answer Distribution</option>
            </select>
          </div>

          {/* Results Info */}
          <div className="space-y-3">
            <label className="flex items-center space-x-2 text-sm font-bold text-gray-800">
              <BookOpen className="h-4 w-4 text-indigo-600" />
              <span>Analysis View</span>
            </label>
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border-2 border-indigo-200 rounded-xl p-3">
              <p className="text-sm font-bold text-indigo-800">
                Question Analysis Dashboard
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Question Analysis Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {questionStats.slice(0, 12).map((question) => (
          <div key={question.questionNumber} className="card-premium rounded-2xl shadow-xl border-2 border-gray-100 p-6 animate-slide-up">
            {/* Question Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-3 shadow-lg">
                  <Target className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-800">{question.questionNumber}</h4>
                  <p className="text-sm text-gray-600">Response Analysis</p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full border text-xs font-bold ${getDifficultyColor(question.difficultyLevel)}`}>
                {question.difficultyLevel}
              </div>
            </div>

            {/* Question Statistics */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="bg-blue-50 rounded-lg p-3 text-center border border-blue-200">
                <div className="text-lg font-bold text-blue-800">{question.totalResponses}</div>
                <div className="text-xs text-blue-600 font-semibold">Responses</div>
              </div>
              <div className="bg-purple-50 rounded-lg p-3 text-center border border-purple-200">
                <div className="text-lg font-bold text-purple-800">{question.responseRate.toFixed(1)}%</div>
                <div className="text-xs text-purple-600 font-semibold">Response Rate</div>
              </div>
              <div className="bg-green-50 rounded-lg p-3 text-center border border-green-200">
                <div className="text-lg font-bold text-green-800">{question.mostCommonAnswer}</div>
                <div className="text-xs text-green-600 font-semibold">Most Common</div>
              </div>
            </div>

            {question.chartData.length > 0 ? (
              <>
                {/* Chart */}
                <div className="h-48 mb-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={question.chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis 
                        dataKey="answer" 
                        tick={{ fontSize: 12, fontWeight: 'bold' }}
                        stroke="#64748b"
                      />
                      <YAxis 
                        tick={{ fontSize: 12, fontWeight: 'bold' }}
                        stroke="#64748b"
                        label={{ value: 'Count', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar 
                        dataKey="count" 
                        fill="url(#colorGradient)"
                        radius={[4, 4, 0, 0]}
                      />
                      <defs>
                        <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#3b82f6" />
                          <stop offset="100%" stopColor="#6366f1" />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Answer Breakdown */}
                <div className="space-y-2">
                  <h5 className="text-sm font-bold text-gray-800 mb-3">Answer Distribution:</h5>
                  <div className="grid grid-cols-1 gap-2">
                    {question.chartData.map((answer, index) => (
                      <div 
                        key={answer.answer}
                        className="flex items-center justify-between p-3 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center shadow-md">
                            <span className="text-white font-bold text-sm">{answer.answer}</span>
                          </div>
                          <span className="text-sm font-bold text-gray-800">{answer.count} students</span>
                        </div>
                        <span className="text-sm font-bold text-blue-600">{answer.percentage.toFixed(1)}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <div className="text-gray-400 mb-4">
                  <Target className="h-12 w-12 mx-auto opacity-50" />
                </div>
                <p className="text-gray-500 font-medium">No responses found for this question</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Difficulty Overview Chart */}
      {questionStats.length > 0 && (
        <div className="card-premium rounded-3xl shadow-xl border-2 border-gray-100 p-8 animate-slide-up">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-3 shadow-xl animate-pulse-glow">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold gradient-text">Question Difficulty Overview</h3>
              <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl p-3 shadow-xl animate-pulse-glow" style={{ animationDelay: '0.5s' }}>
                <Award className="h-6 w-6 text-white" />
              </div>
            </div>
            <p className="text-gray-600 font-medium">Performance trends across all questions</p>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={questionStats} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis 
                  dataKey="questionNumber" 
                  tick={{ fontSize: 12, fontWeight: 'bold' }}
                  stroke="#64748b"
                />
                <YAxis 
                  tick={{ fontSize: 12, fontWeight: 'bold' }}
                  stroke="#64748b"
                  label={{ value: 'Response Rate (%)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-4 rounded-xl shadow-2xl border-2 border-blue-200">
                          <p className="font-bold text-gray-800 mb-1">{label}</p>
                          <p className="text-blue-600 font-semibold">Response Rate: {data.responseRate.toFixed(1)}%</p>
                          <p className="text-green-600 font-semibold">Difficulty: {data.difficultyLevel}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="responseRate" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: '#3b82f6', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {filteredQuestions.length === 0 && (
        <div className="card-premium rounded-2xl shadow-xl border-2 border-gray-100 p-12 text-center animate-slide-up">
          <div className="text-gray-400 mb-6">
            <Search className="h-16 w-16 mx-auto opacity-50" />
          </div>
          <h4 className="text-xl font-bold text-gray-600 mb-2">No Questions Found</h4>
          <p className="text-gray-500">Try adjusting your search criteria or check if the data contains question responses.</p>
        </div>
      )}
    </div>
  );
};